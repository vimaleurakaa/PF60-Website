const activityPane = document.getElementById("activityPane");

activityPane.innerHTML = `
<div class="activity">
                <img src="./images/activities/icon_000.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon2-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_10-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_11-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_12-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_13-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_15-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_16-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_17-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_18-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_19-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_20-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_21-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_22-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_23-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_24-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_25-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_26-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_28-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img
                  src="./images/activities/icon_29-01.svg"
                  alt="activities"
                />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_3-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_4-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_5-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_6-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_7-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_8-01.svg" alt="activities" />
              </div>
              <div class="activity">
                <img src="./images/activities/icon_9-01.svg" alt="activities" />
              </div>`;
