const activityPane = document.getElementById("activityPane");

activityPane.innerHTML = `
              <a href="/activities.html#athleticsacademies">
              <div class="activity">
                <img src="./images/activities/icon_000.svg" alt="activities" />
              </div>
              </a>
              <a href="/activities.html#golfacademies">
              <div class="activity">
                <img src="./images/activities/icon2-01.svg" alt="activities" />
              </div>
              </a>

              <a href="/activities.html#chessacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_10-01.svg"
                  alt="activities"
                />
              </div>
              </a>

              <a href="/activities.html#boxingacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_11-01.svg"
                  alt="activities"
                />
              </div>
              </a>

              <a href="/activities.html#basketballacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_12-01.svg"
                  alt="activities"
                />
              </div>
              </a>

              <a href="/activities.html#badmintonacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_13-01.svg"
                  alt="activities"
                />
              </div>
              </a>

              <a href="/activities.html#volleyballacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_15-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#tabletennisacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_16-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#taekwandoacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_17-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#tabletennisacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_18-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#swimmingacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_19-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#squashacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_20-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#rugbyacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_21-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#rollerskatingacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_22-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#racingacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_23-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#parkouracademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_24-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#martialartsacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_26-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#iceskatingacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_28-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#handballacademies">
              <div class="activity">
                <img
                  src="./images/activities/icon_29-01.svg"
                  alt="activities"
                />
              </div></a>

              <a href="/activities.html#footballacademies">
              <div class="activity">
                <img src="./images/activities/icon_3-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#fitnessacademies">
              <div class="activity">
                <img src="./images/activities/icon_4-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#fieldhockeyacademies">
              <div class="activity">
                <img src="./images/activities/icon_5-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#fencingacademies">
              <div class="activity">
                <img src="./images/activities/icon_6-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#danceacademies">
              <div class="activity">
                <img src="./images/activities/icon_7-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#cricketacademies">
              <div class="activity">
                <img src="./images/activities/icon_8-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#climbingacademies">
              <div class="activity">
                <img src="./images/activities/icon_9-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#gymnasticsacademies">
              <div class="activity">
                <img src="./images/activities/icons-01.svg" alt="activities" />
              </div></a>

              <a href="/activities.html#esportsacademies">
              <div class="activity">
                <img src="./images/activities/E-sports.svg" alt="activities"/>
              </div></a>
              `;
